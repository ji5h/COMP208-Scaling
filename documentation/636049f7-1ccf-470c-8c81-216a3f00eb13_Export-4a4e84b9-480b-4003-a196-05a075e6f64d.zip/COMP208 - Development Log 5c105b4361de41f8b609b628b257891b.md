# COMP208 - Development Log

## Contract - Scaling

**Locomotion** - Robot will be capable of climbing or jumping two flights of stairs. Expect a min of 20 stairs and either a 90 degree or 180 degree turn between flights.

**Goal** - It is load bearing and should carry 2kg of weight (for example shopping bag) to the top of stairs without dropping the load. Placed at bottom of stairs and easily removable at the top. Will start and end on level ground.

### Constraints

- No form of gantry or crane to reach target
- Robot should be single self-contained unit
- No dropping object during ascent
- Can fall during ascent but should reset and return to completing goal

### Recommendations

- Consider many methods of climbing and jumping for simplest most effective method. Look at biomimicry (how animals at height traverse environment)
- Have a method to report the status of robot to user and to log errors and calibration issues
- Consider basket or load-containing structure on top of robot
- How to detect if robot has reached a turn? Consider the sensors and or mapping to achieve this it should be fully autonomous

### Condensed requirements:

Climb stairs.

Carry 2kg.

Turn variable amount of degrees.

### Ways to achieve requirements:

Climb Stairs:

- Wheels with some form of external feet that would help hook onto the stairs
- Jumping where it can hop up each individual stair (may require more complex vision and mapping and load container)
- Some form of raised tank tracks that are permanently at an angle and help with traction (tank tracks will require to change the angle of them depending on the angle of the stairs how do we detect the angle?) https://docs.google.com/document/d/1W2TeU4i8153FuLejfbfsoq7PUXol_FTQb_bXV0Blf7k/edit?pli=1#heading=h.3rdcrjn

Carry 2kg: (Need to consider positioning of the basket (central, back or front))

- Some form of basket mounted on top (could be too loosely held, good for prototype for the first stage of locomotion)
- Some form of grabbing mechanism using motors to close around the package to form a tight grip
- Soft material with a small sticky property that will mean some force is required to remove it (this could have issues with removing at the end)
- Platform that is self regulating using a gyroscope to stabilize the load

Turn variable amount of degrees: 

- Ultrasonic sensor array to detect how close something is (if close means a stair is present if not turn move forward a certain amount)
- LDR sensors for light rather than ultrasonic
- Camera to do high level machine vision

Order of processes:

1. Sort the climbing the flight ( good first stage as completes the simplest process)
2. Sort the turning (software heavy wont require much change in the original movement as the wheels are already there)
3. Sort the carrying (hardware heavy so good for final product to be changed)

## Research on ascending stairs and the basic locomotion

Considering the tank track ascending using a sensor that is attached to a servo and have it move from being at a 90 degree angle from the stairs and have it move until the distance is a certain value of distance away and angle the tracks based on that value.

Another idea on how this could work is by raising the tracks to a 90 degree angle initial and then lowering them into a collision is detected between the track and the stairs this could be determined by if the motor is outputting more power to try and move it (PID motor).

### Furthermore in terms of using power and motors for detection of angle:

PID Control - Detect the power output of a PID motor if the power output becomes greater means that it is colliding with the stairs then remain at that angle.

Basic Motor Control - From a vertical position lower the tracks by a lower power usage for a specified amount of time then begin forward motion. (simple good for prototyping)

## Prototyping

The prototype that I am generating is the tank track. This first stage of this prototype is detecting the angle of the stairs. 

[https://www.youtube.com/watch?app=desktop&v=VoqLz2RHDR0](https://www.youtube.com/watch?app=desktop&v=VoqLz2RHDR0)

[https://docs.google.com/document/d/1W2TeU4i8153FuLejfbfsoq7PUXol_FTQb_bXV0Blf7k/edit?pli=1#heading=h.3rdcrjn](https://docs.google.com/document/d/1W2TeU4i8153FuLejfbfsoq7PUXol_FTQb_bXV0Blf7k/edit?pli=1#heading=h.3rdcrjn)

PID Control - Detect the power output of a PID motor if the power output becomes greater means that it is colliding with the stairs then remain at that angle.

Basic Motor Control - From a vertical position lower the tracks by a lower power usage for a specified amount of time then begin forward motion. (simple good for prototyping)

Prototype: To test the angle detection just have a box with a stick with a motor attached to it to detect the angle using the basic motor control theory.

[](https://youtube.com/shorts/80kRBiH7n5w?feature=share)

### Adding movement

First to test movement of a vehicle I used some basic motors to make a small component drive with a hbridge.

### Tank Tracks - 19/11/23

For the first initial test I will be using gears to turn some tank tracks of a variable size. To do this I will print a fixed plate and have a raised large gear with a hand crank to turn a smaller gear which is on top of a gear that the tank track will fit around.

![IMG_0225.jpeg](COMP208%20-%20Development%20Log%205c105b4361de41f8b609b628b257891b/IMG_0225.jpeg)

This didn’t work as I didn’t take into account the fact that the tank tracks width meant that the gear that fits into it needs to be raised. Also the teeth of the gear weren’t quite big enough so I increased the length to make it fit better.

To fix this issue I’m going to take some scrap wood and cut it into small cubes the go under my gear and will place two new gears on the other side of the plate and transfer the rotation by having the bolt hold the gears on both sides.

### 20/11/23

[https://www.youtube.com/shorts/C0xMxuMEgGQ](https://www.youtube.com/shorts/C0xMxuMEgGQ)

### Tank Track Moving Object - 21/11/23

The next step I will edit the gears in fusion to have holes that will fit the motors rather than bolts and attach them to an insert from my toolbox.

![image_2023-11-21_163215124.png](COMP208%20-%20Development%20Log%205c105b4361de41f8b609b628b257891b/image_2023-11-21_163215124.png)

As you can see I also took into account the fact that the tank tracks need to be away from other objects so I made the hole for the motor have height to give more spacing.

### Testing - 22/11/23

When testing these gears I am going to rapidly prototype by using my toolbox insert some scrap wood, loose bolts and glue for my first system.

![IMG_0235.jpeg](COMP208%20-%20Development%20Log%205c105b4361de41f8b609b628b257891b/IMG_0235.jpeg)

![IMG_0245.jpeg](COMP208%20-%20Development%20Log%205c105b4361de41f8b609b628b257891b/IMG_0245.jpeg)

![IMG_0238.jpeg](COMP208%20-%20Development%20Log%205c105b4361de41f8b609b628b257891b/IMG_0238.jpeg)

This first prototype didn’t work as the teeth are too pointed and got stuck between the tank tracks meaning it would jolt and fall off. So I then redesigned the gears for the tank track using the inbuilt gear system so I would not encounter this issue.

![image_2023-11-22_165433368.png](COMP208%20-%20Development%20Log%205c105b4361de41f8b609b628b257891b/image_2023-11-22_165433368.png)

I then printed two out so that I could test them with the tank tracks by gluing two motors onto the toolbox insert.

[https://www.youtube.com/shorts/rzVXH5URpOQ](https://www.youtube.com/shorts/rzVXH5URpOQ)

As you can see in this video the tank track kept becoming dislodged and stopped working. To fix this I drilled a hole into my toolbox and stuck a screw through just above the tank track to add some more tension which seemed to do the trick.

[https://www.youtube.com/shorts/A5rG2baKnjw](https://www.youtube.com/shorts/A5rG2baKnjw)

After I got both sides working I attempted to place it on the stairs however it couldn’t get enough traction. To fix this issue I’m going to look at conventional tank tracks and create some idler gears at the bottom of the tracks to add tension.

### Adding traction to tracks - 24/11/23

First I modelled a chassis that would fix onto the tool box and hold the gears close to the bottom of the tank track. To do this I took measurements of the small tank track to create a model in fusion 360 and print out the chassis.

![image_2023-11-27_110237910.png](COMP208%20-%20Development%20Log%205c105b4361de41f8b609b628b257891b/image_2023-11-27_110237910.png)

As you can see I wasn’t entirely sure where the gears would be best placed so I added many holes that can fit the gears so that I can choose the best placement when its printed out.

To hold the gears in the chassis I created a small cap that would fit perfectly to the back of the gear to fasten it in place.

![image_2023-11-27_110431783.png](COMP208%20-%20Development%20Log%205c105b4361de41f8b609b628b257891b/image_2023-11-27_110431783.png)

I then printed them out and assembled the component.

![IMG_0255.jpeg](COMP208%20-%20Development%20Log%205c105b4361de41f8b609b628b257891b/IMG_0255.jpeg)

I then drilled two holes into the tool box insert to fasten the gear holder.

[https://youtube.com/shorts/9YpiUEqMJm0?si=vdMQoAtrJytTOwO6](https://youtube.com/shorts/9YpiUEqMJm0?si=vdMQoAtrJytTOwO6)

### 28/11/23

I then added the other side to the chassis.

![IMG_0260.jpeg](COMP208%20-%20Development%20Log%205c105b4361de41f8b609b628b257891b/IMG_0260.jpeg)

However I found that it was not providing enough power to move the tracks so I made a smaller gear in fusion 360 and used that instead. 

![IMG_0263.jpeg](COMP208%20-%20Development%20Log%205c105b4361de41f8b609b628b257891b/IMG_0263.jpeg)

### 29/11/23

Then I was having issues the the tank track remaining stable on the left most idler so I stuck another gear on top of it to put it more inline with the other gears which sorted the problem of it flying off. 

![IMG_0265.jpeg](COMP208%20-%20Development%20Log%205c105b4361de41f8b609b628b257891b/IMG_0265.jpeg)

After that I fastened all of the electronics onto the toolbox insert and added a switch so that I could not have it constantly running. 

![IMG_0268.jpeg](COMP208%20-%20Development%20Log%205c105b4361de41f8b609b628b257891b/IMG_0268.jpeg)

After I finished this I tested how it would run attempting to grip onto stairs. 

[https://youtube.com/shorts/XeLulx0r4zA?si=Iy4U-g0JRL_M4on3](https://youtube.com/shorts/XeLulx0r4zA?si=Iy4U-g0JRL_M4on3)

**What I learnt from this test:** 

- Tank tracks don’t give enough traction to climb stairs.
- Toolbox comes at the stairs too low.
- The tank tracks are too small to grab multiple stairs.
- Tank tracks occasionally get stuck against the insert as they are close.
- The motors I’m using don’t have enough torque and aren’t encoded motors.

**What I will do for the next prototype based on this test:**

- Design new tank track segments that will provide better grip to climb stairs.
- Raise the tool box with a larger tank track chassis.
- Make more tank track segments and gears so that the tracks are longer.
- Laser cut the chassis so that it is more rigid and quicker to make the next version of.
- Make the segments wider so there is a larger contact with the stairs.
- Move the tank tracks further out so that there is no chance to catch on the toolbox insert.
- Will replace the yellow dc motors with an encoded motor on both sides and centralise the output of rotation and use some gears to control the torque provided to the tank tracks.

### Tank track segments - 30/11/23

The first thing I will be improving is the tank tracks themselves and to do this I will be printing individual segments that will provide more grip. 

First I modelled the tank tracks and then designed them in fusion 360 and then made modifications to improve the grip.

I went through 19 iterations of tank track segments and found that with using PLA you have to thicken the connecting part as it is more brittle so can snap. I also found that the best gripping method that I found is a L shaped tank track.

![image_2023-12-05_142727825.png](COMP208%20-%20Development%20Log%205c105b4361de41f8b609b628b257891b/image_2023-12-05_142727825.png)

### 02/12/23

[https://youtube.com/shorts/k1oGFfx_7WM?si=IBy8IOZyg-g5TGoy](https://youtube.com/shorts/k1oGFfx_7WM?si=IBy8IOZyg-g5TGoy)

After getting my prototype to work we compared both prototypes and decided to go forward with the linear actuator project as it has less steps to complete to make it to the end of the project.

I will be handling the laser sensing to detect the distance. To begin I will get a microcontroller to utilize multiple laser sensors.

### 24/12/23

![IMG_0413.jpeg](COMP208%20-%20Development%20Log%205c105b4361de41f8b609b628b257891b/IMG_0413.jpeg)

![IMG_0414.jpeg](COMP208%20-%20Development%20Log%205c105b4361de41f8b609b628b257891b/IMG_0414.jpeg)

### 02/01/24

After getting this done I found that the uno didn’t have enough dynamic memory to run more than two sensors so I needed to use a mega with a larger amount of dynamic memory to use three sensors.

```arduino
#include "Adafruit_VL53L0X.h"

// Addresses for the three sensors
#define LOXL_ADDRESS 0x30
#define LOXR_ADDRESS 0x31
#define LOXF_ADDRESS 0x32

// Pins to control sensor shutdown
#define SHT_LOXL 6
#define SHT_LOXR 7
#define SHT_LOXF 5

// Objects for the VL53L0X sensors
Adafruit_VL53L0X loxL = Adafruit_VL53L0X();
Adafruit_VL53L0X loxR = Adafruit_VL53L0X();
Adafruit_VL53L0X loxF = Adafruit_VL53L0X();

// Measurement data for the three sensors
VL53L0X_RangingMeasurementData_t measureL;
VL53L0X_RangingMeasurementData_t measureR;
VL53L0X_RangingMeasurementData_t measureF;

void setID() {
  // Reset all sensors
  digitalWrite(SHT_LOXL, LOW);
  digitalWrite(SHT_LOXR, LOW);
  digitalWrite(SHT_LOXF, LOW);
  delay(10);

  // Activate LOX1, reset LOX2 and LOX3
  digitalWrite(SHT_LOXL, HIGH);
  
  // Init LOX1
  loxL.begin(LOXL_ADDRESS);
  delay(10);

  // Activate LOX2, reset LOX1 and LOX3
  digitalWrite(SHT_LOXR, HIGH);
  delay(10);

  // Init LOX2
  loxR.begin(LOXR_ADDRESS);
  delay(10);

  // Activate LOX3, reset LOX1 and LOX2
  digitalWrite(SHT_LOXF, HIGH);
  delay(10);

  // Init LOX3
  loxF.begin(LOXF_ADDRESS);
}

void read_triple_sensors() {
  loxL.rangingTest(&measureL, false);
  loxR.rangingTest(&measureR, false);
  loxF.rangingTest(&measureF, false);

  // Print sensor one reading
  Serial.print(F("1: "));
  Serial.print(measureL.RangeMilliMeter);
  Serial.print(F(" "));

  // Print sensor two reading
  Serial.print(F("2: "));
  Serial.print(measureR.RangeMilliMeter);
  Serial.print(F(" "));

  // Print sensor three reading
  Serial.print(F("3: "));
  Serial.print(measureF.RangeMilliMeter);
  Serial.println();
}

void setup() {
  Serial.begin(115200);

  // Wait until the serial port opens for native USB devices
  while (!Serial) {
    delay(1);
  }

  pinMode(SHT_LOXL, OUTPUT);
  pinMode(SHT_LOXR, OUTPUT);
  pinMode(SHT_LOXF, OUTPUT);

  Serial.println(F("Shutdown pins inited..."));

  digitalWrite(SHT_LOXL, LOW);
  digitalWrite(SHT_LOXR, LOW);
  digitalWrite(SHT_LOXF, LOW);

  Serial.println(F("All in reset mode...(pins are low)"));

  Serial.println(F("Starting..."));
  setID();
}

void loop() {
  read_triple_sensors();
  delay(100);
}
```

![IMG_0589.jpeg](COMP208%20-%20Development%20Log%205c105b4361de41f8b609b628b257891b/IMG_0589.jpeg)

![IMG_0588.jpeg](COMP208%20-%20Development%20Log%205c105b4361de41f8b609b628b257891b/IMG_0588.jpeg)

My next step is to integrate the laser sensors into the main robot and begin writing the code to make it move autonomously. 

![IMG_0591.jpeg](COMP208%20-%20Development%20Log%205c105b4361de41f8b609b628b257891b/IMG_0591.jpeg)

![rn_image_picker_lib_temp_66bcf236-5ba7-48c5-9e22-616c628f85e3.jpeg](COMP208%20-%20Development%20Log%205c105b4361de41f8b609b628b257891b/rn_image_picker_lib_temp_66bcf236-5ba7-48c5-9e22-616c628f85e3.jpeg)

![rn_image_picker_lib_temp_67e31005-ba37-459d-8467-5dccb74a915c.jpeg](COMP208%20-%20Development%20Log%205c105b4361de41f8b609b628b257891b/rn_image_picker_lib_temp_67e31005-ba37-459d-8467-5dccb74a915c.jpeg)

Here is the main robot with the laser sensors attached onto it with the data being read through serial.

After this the next step is to remake the chassis including the laser sensor mounts that were modelled by Jason.

![image_2024-01-02_183144437.png](COMP208%20-%20Development%20Log%205c105b4361de41f8b609b628b257891b/image_2024-01-02_183144437.png)

As you an see there are many laser sensor mounts this is because for the first model of the chassis I don’t want to limit the possible places where the laser sensors can be placed. 

### 03/01/24

Reduced the original models slots for the linear actuators as well to make it friction fit.

Simon also modelled a battery holder to go in-between the acrylic board and the chassis which I added a decal of falmouth robotics on for aesthesis. 

![image_2024-01-03_153405651.png](COMP208%20-%20Development%20Log%205c105b4361de41f8b609b628b257891b/image_2024-01-03_153405651.png)

However in this version i made it far too indented so i reduced the 1.6mm indent to a 0.2mm indent for the final version but the slight mess up will be fine for printing a first draft.

Using these parts I discovered some issues:

Issue 1: The indent is too deep on the battery holder so will decrease it.

Issue 2: The laser sensors are coming into contact with the mount so I will have to edit it to have some space so that it will not come into contact.

![IMG_0604.jpeg](COMP208%20-%20Development%20Log%205c105b4361de41f8b609b628b257891b/IMG_0604.jpeg)

![IMG_0606.jpeg](COMP208%20-%20Development%20Log%205c105b4361de41f8b609b628b257891b/IMG_0606.jpeg)

Issue 3: The battery holders bolt slot was slightly off the ground meaning it got printed with supports and not to a high quality so I will fix that.

Issue 4: The measurements are slightly off width wise so will increase 1mm either side.

### 04/01/24

First thing to do is to print off a new battery holder and a new chassis with a better design of laser sensor mount and a tighter hole size of 20.2mm which gives a very good friction fit.

![image.jpg](COMP208%20-%20Development%20Log%205c105b4361de41f8b609b628b257891b/image.jpg)

Next I will print off a new battery holder that will fit  the battery much better and put it all together.

![IMG_0609.jpeg](COMP208%20-%20Development%20Log%205c105b4361de41f8b609b628b257891b/IMG_0609.jpeg)

![IMG_0611.jpeg](COMP208%20-%20Development%20Log%205c105b4361de41f8b609b628b257891b/IMG_0611.jpeg)

### 05/01/24

As well as coding the functionality of the robot we still need to attach a load holder so I created a basket that would hold a bag with a handle so that any bag of any size can fit and be enclosed so no sway occurs with holding a bag.

![IMG_0630.jpeg](COMP208%20-%20Development%20Log%205c105b4361de41f8b609b628b257891b/IMG_0630.jpeg)

However after printing it out it can be seen it is far too small to fit any bags in so we decided to go for a basket holder design which I will make to be very sturdy to avoid breaking due to a load.

![IMG_0634.jpeg](COMP208%20-%20Development%20Log%205c105b4361de41f8b609b628b257891b/IMG_0634.jpeg)

 

### 07/01/24

Further usage of the laser sensors caused them to overheat due to the amount of information that was being sent across the I2C bus, this caused many of them to break so we have had to reduce to only using one front laser sensor rather than the four previously planned for turning giving it less intelligence about its surroundings but will be able to achieve the turning aspect.

This means I will change the laser sensing code to only have one time of flight sensor class so no xShuts needed.

### 09/01/24

I then began programming the main by creating a finite state machine.

```arduino
#include "Adafruit_VL53L0X.h"

enum State {STATIONARY, FORWARD, ROTATE_RIGHT, ROTATE_LEFT, RAISE, LOWER, IDLE, CLIMB};

State currentState = FORWARD;
// #include <Encoder.h>

// //code for encoders
// Encoder motorBackL (2,4);
// Encoder motorBackR (3,5);

// Encoder motorFrontL (20,6);
// Encoder motorFrontR (21,7);

// long int posBackL = 0;
// long int posBackR = 0;

// long int posFrontL = 0;
// long int posFrontR = 0;

// int gearingBackL = 45;
// int ticksPerRevolutionBackL = 2791;

// int gearingBackR = 45;
// int ticksPerRevolutionBackR = 2767;

// int gearingFrontL = 45;
// int ticksPerRevolutionFrontL = 2791;

// int gearingFrontR = 45;
// int ticksPerRevolutionFrontR = 2767;

// float wheelRadius = 35;
// float wheelCircumference = 2 * 3.14 * wheelRadius;

// //distance to move the robot
// int distanceBackL = 1000/5;
// int distanceBackR = 1000/5;

// int distanceFrontL = 1000/5;
// int distanceFrontR = 1000/5;

//-------------------------------------------------------------------------------------------------------------
int motEn1 = 13; // motor 1 enable pin for setting power
int motEn2 = 12;
int motEn3 = 11;
int motEn4 = 10;

int mot1a = 22; // mot1a and mot 1b to set direction for motor 1
int mot1b = 24;
int mot2a = 26;
int mot2b = 28;
int mot3a = 34;
int mot3b = 36;
int mot4a = 38;
int mot4b = 40;

//-------------------------------------------------------------------------------------------------------------

int linearActuator1a= 39; //1a and 1b for 1st linear actuator to set direction
int linearActuator1b= 41;
int linearActuator2a= 43;
int linearActuator2b= 45;
int linearActuator4a= 47;
int linearActuator4b= 49;
int linearActuator3a= 51;
int linearActuator3b= 53;

///linear actuator enable pins (pwm)
int linearAcuatorEn1 = 32;
int linearAcuatorEn2 = 30;
int linearAcuatorEn3 = 4;
int linearAcuatorEn4 = 5;

//-----------------------------------------------------------------------------------------------------------------------
// initialising whisker sensors

//int frontWhisker
//int whiskerActuator1
//int whiskerActuator2
//int whiskerActuator3
//int whiskerActuator4

//-----------------------------------------------------------------------------------------------------------------------

//laser sensing code

// Objects for the VL53L0X sensors
Adafruit_VL53L0X tof = Adafruit_VL53L0X();

// Measurement data 
VL53L0X_RangingMeasurementData_t measure;

void setup() { 
  pinMode(motEn1, OUTPUT);
  pinMode(motEn2, OUTPUT);
  pinMode(motEn3, OUTPUT);
  pinMode(motEn4, OUTPUT);

  pinMode(mot1a, OUTPUT);
  pinMode(mot1b, OUTPUT);
  pinMode(mot2a, OUTPUT);
  pinMode(mot2b, OUTPUT);
  pinMode(mot3a, OUTPUT);
  pinMode(mot3b, OUTPUT);
  pinMode(mot4a, OUTPUT);
  pinMode(mot4b, OUTPUT);
   
    
  Serial.begin(115200);
  pinMode(linearActuator1a, OUTPUT);
  pinMode(linearActuator1b, OUTPUT);
  pinMode(linearActuator2a, OUTPUT);
  pinMode(linearActuator2b, OUTPUT);
  pinMode(linearActuator3a, OUTPUT);
  pinMode(linearActuator3b, OUTPUT);
  pinMode(linearActuator4a, OUTPUT);
  pinMode(linearActuator4b, OUTPUT);

  //initialise tof
  if(!tof.begin()) {
    Serial.println("failed to initiate tof");
  }
}

void actuatorOneUp()
{   
  digitalWrite(linearActuator1a,LOW);
  digitalWrite(linearActuator1b,HIGH);
  analogWrite(linearAcuatorEn1, 150);
} 
  
void actuatorOneDown() {   
  digitalWrite(linearActuator1a,HIGH);
  digitalWrite(linearActuator1b,LOW);
  analogWrite(linearAcuatorEn1, 150); 
}

void actuatorOneStop () {
  digitalWrite(linearActuator1a,LOW);
  digitalWrite(linearActuator1b,LOW);  
}

void actuatorTwoUp() {
  digitalWrite(linearActuator2a,HIGH);
  digitalWrite(linearActuator2b,LOW);
  analogWrite(linearAcuatorEn2, 150);
}
     
void actuatorTwoDown() {
  digitalWrite(linearActuator2a,LOW);
  digitalWrite(linearActuator2b,HIGH);
  analogWrite(linearAcuatorEn2, 150);
}

void actuatorTwoStop () {
  digitalWrite(linearActuator2a,LOW);
  digitalWrite(linearActuator2b,LOW);  
}

void actuatorThreeUp() {
  digitalWrite(linearActuator3a,HIGH);
  digitalWrite(linearActuator3b,LOW);
  analogWrite(linearAcuatorEn3, 150);
}
     
void actuatorThreeDown() {
  digitalWrite(linearActuator3a,LOW);
  digitalWrite(linearActuator3b,HIGH);
  analogWrite(linearAcuatorEn3, 150);
}

void actuatorThreeStop () {
  digitalWrite(linearActuator3a,LOW);
  digitalWrite(linearActuator3b,LOW);  
}

void actuatorFourUp() {
  digitalWrite(linearActuator4a,HIGH);
  digitalWrite(linearActuator4b,LOW);
  analogWrite(linearAcuatorEn4, 150);
}
     
void actuatorFourDown() {
  digitalWrite(linearActuator4a,LOW);
  digitalWrite(linearActuator4b,HIGH);
  analogWrite(linearAcuatorEn4, 150);
}

void actuatorFourStop () {
  digitalWrite(linearActuator4a,LOW);
  digitalWrite(linearActuator4b,LOW);  
}

void allActuatorsDown(){
  actuatorOneDown();
  actuatorTwoDown();
  actuatorThreeDown();
  actuatorFourDown();
}

void allActuatorsUp(){
  actuatorOneUp();
  actuatorTwoUp();
  actuatorThreeUp();
  actuatorFourUp();
}

void allActuatorsStop(){
  actuatorOneStop();
  actuatorTwoStop();
  actuatorThreeStop();
  actuatorFourStop();
}

void middleActuatorsUp(){
  actuatorTwoUp();
  actuatorThreeUp();
}

void middleActuatorsDown(){
  actuatorTwoDown();
  actuatorThreeDown();
}

//functions for control of the motors
void motFrontRightFwd () {
  digitalWrite(mot1a, HIGH);
  digitalWrite(mot1b, LOW);
  analogWrite(motEn1, 255);
}

void motRearRightFwd () {
  digitalWrite(mot2a, LOW);
  digitalWrite(mot2b, HIGH);
  analogWrite(motEn2, 255);
}

void motRearLeftFwd () {
  digitalWrite(mot3a, LOW);
  digitalWrite(mot3b, HIGH);
  analogWrite(motEn3, 255);
}

void motFrontLeftFwd () {
  digitalWrite(mot4a, HIGH);
  digitalWrite(mot4b, LOW);
  analogWrite(motEn4, 255);
}

void frontMotForward(){
  motFrontRightFwd();
  motFrontLeftFwd();
}

void rearMotForward(){
  motRearRightFwd();
  motRearLeftFwd();
}

void allMotForward(){
  frontMotForward();
  rearMotForward();
}

void allMotStop () {
  digitalWrite(mot1a, LOW);
  digitalWrite(mot1b, LOW);
  analogWrite(motEn1, 0);
  digitalWrite(mot2a, LOW);
  digitalWrite(mot2b, LOW);
  analogWrite(motEn2, 0);
  digitalWrite(mot3a, LOW);
  digitalWrite(mot3b, LOW);
  analogWrite(motEn3, 0);
  digitalWrite(mot4a, LOW);
  digitalWrite(mot4b, LOW);
  analogWrite(motEn4, 0);
}

void allMotReverse(){
  digitalWrite(mot1a, LOW);
  digitalWrite(mot1b, HIGH);
  analogWrite(motEn1, 125);
  digitalWrite(mot2a, HIGH);
  digitalWrite(mot2b, LOW);
  analogWrite(motEn2, 125);  
  digitalWrite(mot3a, HIGH);
  digitalWrite(mot3b, LOW);
  analogWrite(motEn3, 125); 
  digitalWrite(mot4a, LOW);
  digitalWrite(mot4b, HIGH);
  analogWrite(motEn4, 125); 
}

void loop() {
  
  tof.rangingTest(&measure, false);
  Serial.println(measure.RangeMilliMeter);

  //digitalRead(frontWhisker) == HIGH
  if (true) {
    currentState = CLIMB;
  }

  switch (currentState) {
    case STATIONARY:
     allMotStop();
     allActuatorsStop();
     break;
    
    case FORWARD:
      allMotForward();
      break;
    
    case ROTATE_RIGHT:
      motFrontLeftFwd();
      motRearLeftFwd();
      break;

    case ROTATE_LEFT:
      motFrontRightFwd();
      motRearLeftFwd();
      break;
    
    case RAISE:
      allActuatorsDown();
      break;

    case LOWER:
      allActuatorsUp();
      break;
    
    case IDLE:
      allActuatorsStop();
      break;

    case CLIMB:
    //raising first actuator above stairs and lowering till it hits it
      actuatorOneUp();
      delay(25000);
      allMotForward();
      delay(25000);
      allMotStop();
      //digitalRead(whiskerActuator1) == LOW
      if (false) {
        actuatorOneDown();
      } else {
        actuatorOneStop();
      }

      //moving the middle actuators above stairs and lowering them until each whisker detects ground
      middleActuatorsUp();
      delay(25000);
      allMotForward();
      delay(25000);
      allMotStop();
      //digitalRead(whiskerActuator2) == LOW
      if (false) {
        actuatorTwoDown();
      } else {
        actuatorTwoStop();
      }
      //digitalRead(whiskerActuator3) == LOW
      if (false) {
        actuatorThreeDown();
      } else {
        actuatorThreeStop();
      }

      //lift final leg above
      actuatorFourUp();
      delay(25000);
      allMotForward();
      delay(25000);
      allMotStop();
      //digitalRead(whiskerActuator4) == LOW
      if (false) {
        actuatorFourDown();
      } else {
        actuatorFourStop();
      }
      
  }

}
```

This code has temporary if statements as the whisker sensors are not yet attached.

### 11/01/23

To attach the whisker sensors due to the nature of the stair case they could get stuck in the tread so to screw them on I will design a cover that has a hinge that can protect the lever from getting stuck in the tread.

![image_2024-01-23_013114496.png](COMP208%20-%20Development%20Log%205c105b4361de41f8b609b628b257891b/image_2024-01-23_013114496.png)

After attempting to use these I found that the size of the hinge is too small and fragile so it snaps far too easily so this method is not viable. Instead Simon is going to adjust the motor mount design to house the whisker sensors perpendicular to the stairs so it can run over the tread and not break.

### 13/01/24

After printing out the new motor mounts we attached them to the robot and attached the whisker sensors to them.

### 15/01/24

Implementing basic odometry to then do PID.

```arduino
//code for encoders
Encoder motorBackL (2,6);
Encoder motorBackR (3,7);

Encoder motorFrontL (50,8);
Encoder motorFrontR (52,9);

long int posBackL = 0;
long int posBackR = 0;

long int posFrontL = 0;
long int posFrontR = 0;

int gearingBackL = 45;
int ticksPerRevolutionBackL = 6000;

int gearingBackR = 47;
int ticksPerRevolutionBackR = 6067;

int gearingFrontL = 21;
int ticksPerRevolutionFrontL = 2791;

int gearingFrontR = 45;
int ticksPerRevolutionFrontR = 2767;

float wheelRadius = 29;
float wheelCircumference = 2 * 3.14 * wheelRadius;

//distance to move the robot
int distanceBackL = 1000/5;
int distanceBackR = 1000/5;

int distanceFrontL = 1000/5;
int distanceFrontR = 1000/5;
```

While attempting to code the encoded motors I found out that an arduino mega only has two interrupt pins that are suitable for an encoder so PID will be hard to implement via encoded motors as only two out of the four can be used.

### 17/01/23

I will therefore change the code to only use two encoders.

```arduino
//code for encoders
Encoder motorFrontL (2,6);
Encoder motorFrontR (3,7);

long int posFrontL = 0;
long int posFrontR = 0;

int gearingFrontL = 45;
int ticksPerRevolutionFrontL = 6000;

int gearingFrontR = 47;
int ticksPerRevolutionFrontR = 6067;

float wheelRadius = 29;
float wheelCircumference = 2 * 3.14 * wheelRadius;

//distance to move the robot
int distanceFrontL = 1000/5;
int distanceFrontR = 1000/5;
```

### 18/01/23

After wiring up the first whisker sensor I was then able to begin coding the functionality for the state of CLIMB.

```arduino
#include "Adafruit_VL53L0X.h"
#include <Encoder.h>
enum State {STATIONARY, FORWARD, ROTATE_RIGHT, ROTATE_LEFT, RAISE, LOWER, IDLE, CLIMB};

State currentState = STATIONARY;

//code for encoders
Encoder motorFrontL (2,6);
Encoder motorFrontR (3,7);

long int posFrontL = 0;
long int posFrontR = 0;

int gearingFrontL = 45;
int ticksPerRevolutionFrontL = 6000;

int gearingFrontR = 47;
int ticksPerRevolutionFrontR = 6067;

float wheelRadius = 29;
float wheelCircumference = 2 * 3.14 * wheelRadius;

//distance to move the robot
int distanceFrontL = 1000/5;
int distanceFrontR = 1000/5;

//-------------------------------------------------------------------------------------------------------------
int motEn1 = 13; // motor 1 enable pin for setting power
int motEn2 = 12;
int motEn3 = 11;
int motEn4 = 10;

int mot1a = 22; // mot1a and mot 1b to set direction for motor 1
int mot1b = 24;
int mot2a = 26;
int mot2b = 28;
int mot3a = 34;
int mot3b = 36;
int mot4a = 38;
int mot4b = 40;

//-------------------------------------------------------------------------------------------------------------

int linearActuator1a= 39; //1a and 1b for 1st linear actuator to set direction
int linearActuator1b= 41;
int linearActuator2a= 43;
int linearActuator2b= 45;
int linearActuator4a= 47;
int linearActuator4b= 49;
int linearActuator3a= 51;
int linearActuator3b= 53;

///linear actuator enable pins (pwm)
int linearAcuatorEn1 = 32;
int linearAcuatorEn2 = 30;
int linearAcuatorEn3 = 4;
int linearAcuatorEn4 = 5;

//-----------------------------------------------------------------------------------------------------------------------
// initialising whisker sensors

//int frontWhisker
int whiskerActuator1 = 52;
//int whiskerActuator2
//int whiskerActuator3
//int whiskerActuator4

//-----------------------------------------------------------------------------------------------------------------------

//laser sensing code

// Objects for the VL53L0X sensors
Adafruit_VL53L0X tof = Adafruit_VL53L0X();

// Measurement data 
VL53L0X_RangingMeasurementData_t measure;

void setup() { 
  pinMode(motEn1, OUTPUT);
  pinMode(motEn2, OUTPUT);
  pinMode(motEn3, OUTPUT);
  pinMode(motEn4, OUTPUT);

  pinMode(mot1a, OUTPUT);
  pinMode(mot1b, OUTPUT);
  pinMode(mot2a, OUTPUT);
  pinMode(mot2b, OUTPUT);
  pinMode(mot3a, OUTPUT);
  pinMode(mot3b, OUTPUT);
  pinMode(mot4a, OUTPUT);
  pinMode(mot4b, OUTPUT);
   
  Serial.begin(115200);
  Serial.println("yo");

  pinMode(linearActuator1a, OUTPUT);
  pinMode(linearActuator1b, OUTPUT);
  pinMode(linearActuator2a, OUTPUT);
  pinMode(linearActuator2b, OUTPUT);
  pinMode(linearActuator3a, OUTPUT);
  pinMode(linearActuator3b, OUTPUT);
  pinMode(linearActuator4a, OUTPUT);
  pinMode(linearActuator4b, OUTPUT);

  pinMode(whiskerActuator1, INPUT);

  //initialise tof
  // if(!tof.begin()) {
  //   Serial.println("failed to initiate tof");
  // }
}

void loop() {
  // tof.rangingTest(&measure, false);
  allActuatorsDown();
  delay(5000);
  Serial.println("all actuators raised");

  allMotForward();
  Serial.println("drive to stairs");
  delay(5000);
  
  Serial.println("Climbing");
  currentState = CLIMB;
 
  
  

  //----------------------------------------
  //code to do odometry
  // posFrontL = motorFrontL.read();
  // while (motorFrontL.read() < ticksPerRevolutionFrontL) {
  //   Serial.println(motorFrontL.read());
  //   motFrontLeftFwd();
  // }
  // allMotStop();
  // Serial.println(motorFrontL.read());

  //-----------------------------------------
  //code to switch states based on sensors
  // if (measure.RangeMilliMeter > 100) {
  //   currentState = FORWARD;
  // } else if (measure.RangeMilliMeter > 100 & /* digitalRead(frontWhisker) == HIGH */ true) {
  //     currentState = CLIMB;
  // } else if (/* reached the top of flight 1 */true) {
  //   for (/* certain amount of encoder ticks */ true) {
  //     currentState = ROTATE_RIGHT;
  //   }
  //   for (/* certain amount of encoder ticks */ true) {
  //     currentState = FORWARD;
  //   }
  //   for (/* certain amount of encoder ticks */ true) {
  //     currentState = ROTATE_RIGHT;
  //   }
  // } else if (/* reached top of flight 2 */ true) {
  //   currentState = STATIONARY;
  // } 

  

  switch (currentState) {
    case STATIONARY:
     allMotStop();
     allActuatorsStop();
     break;
    
    case FORWARD:
      allMotForward();
      break;
    
    case ROTATE_RIGHT:
      motFrontLeftFwd();
      motRearLeftFwd();
      break;

    case ROTATE_LEFT:
      motFrontRightFwd();
      motRearRightFwd();
      break;
    
    case RAISE:
      allActuatorsDown();
      break;

    case LOWER:
      allActuatorsUp();
      break;
    
    case IDLE:
      allActuatorsStop();
      break;

    case CLIMB:
    //raising first actuator above stairs and lowering till it hits it
      actuatorOneUp();
      delay(10000);
      allMotForward();
      delay(10000);
      allMotStop();
      
      //check to see if the whisker sensor is pressed down
      Serial.println(digitalRead(whiskerActuator1));
      while (digitalRead(whiskerActuator1) == 0) {
        actuatorOneDown();
      } 
      actuatorOneStop();
      Serial.println("actuator one on stair");
        // //moving the middle actuators above stairs and lowering them until each whisker detects ground
        // middleActuatorsUp();
        // delay(10000);
        // allMotForward();
        // delay(10000);
        // allMotStop();
        // //digitalRead(whiskerActuator2) == LOW
        // //if (false) {
        // actuatorTwoDown();
        // delay(5000);
        // //} else {
        // actuatorTwoStop();
        // //}
        // //digitalRead(whiskerActuator3) == LOW
        // //if (false) {
        // actuatorThreeDown();
        // delay(5000);
        // //} else {
        // actuatorThreeStop();
        // //}

        // //lift final leg above
        // actuatorFourUp();
        // delay(10000);
        // allMotForward();
        // delay(10000);
        // allMotStop();
        // //digitalRead(whiskerActuator4) == LOW
        // //if (false) {
        // actuatorFourDown();
        // delay(5000);
        // //} else {
        // actuatorFourStop();
        // //}
      
      
  }

}

void actuatorOneUp()
{   
  digitalWrite(linearActuator1a,LOW);
  digitalWrite(linearActuator1b,HIGH);
  analogWrite(linearAcuatorEn1, 150);
} 
  
void actuatorOneDown() {   
  digitalWrite(linearActuator1a,HIGH);
  digitalWrite(linearActuator1b,LOW);
  analogWrite(linearAcuatorEn1, 150); 
}

void actuatorOneStop () {
  digitalWrite(linearActuator1a,LOW);
  digitalWrite(linearActuator1b,LOW);  
}

void actuatorTwoUp() {
  digitalWrite(linearActuator2a,HIGH);
  digitalWrite(linearActuator2b,LOW);
  analogWrite(linearAcuatorEn2, 150);
}
     
void actuatorTwoDown() {
  digitalWrite(linearActuator2a,LOW);
  digitalWrite(linearActuator2b,HIGH);
  analogWrite(linearAcuatorEn2, 150);
}

void actuatorTwoStop () {
  digitalWrite(linearActuator2a,LOW);
  digitalWrite(linearActuator2b,LOW);  
}

void actuatorThreeUp() {
  digitalWrite(linearActuator3a,HIGH);
  digitalWrite(linearActuator3b,LOW);
  analogWrite(linearAcuatorEn3, 150);
}
     
void actuatorThreeDown() {
  digitalWrite(linearActuator3a,LOW);
  digitalWrite(linearActuator3b,HIGH);
  analogWrite(linearAcuatorEn3, 150);
}

void actuatorThreeStop () {
  digitalWrite(linearActuator3a,LOW);
  digitalWrite(linearActuator3b,LOW);  
}

void actuatorFourUp() {
  digitalWrite(linearActuator4a,HIGH);
  digitalWrite(linearActuator4b,LOW);
  analogWrite(linearAcuatorEn4, 255);
}
     
void actuatorFourDown() {
  digitalWrite(linearActuator4a,LOW);
  digitalWrite(linearActuator4b,HIGH);
  analogWrite(linearAcuatorEn4, 250);
}

void actuatorFourStop () {
  digitalWrite(linearActuator4a,LOW);
  digitalWrite(linearActuator4b,LOW);  
}

void allActuatorsDown(){
  actuatorOneDown();
  actuatorTwoDown();
  actuatorThreeDown();
  actuatorFourDown();
}

void allActuatorsUp(){
  actuatorOneUp();
  actuatorTwoUp();
  actuatorThreeUp();
  actuatorFourUp();
}

void allActuatorsStop(){
  actuatorOneStop();
  actuatorTwoStop();
  actuatorThreeStop();
  actuatorFourStop();
}

void middleActuatorsUp(){
  actuatorTwoUp();
  actuatorThreeUp();
}

void middleActuatorsDown(){
  actuatorTwoDown();
  actuatorThreeDown();
}

//functions for control of the motors
void motFrontRightFwd () {
  digitalWrite(mot1a, HIGH);
  digitalWrite(mot1b, LOW);
  analogWrite(motEn1, 255);
}

void motRearRightFwd () {
  digitalWrite(mot2a, LOW);
  digitalWrite(mot2b, HIGH);
  analogWrite(motEn2, 255);
}

void motRearLeftFwd () {
  digitalWrite(mot3a, LOW);
  digitalWrite(mot3b, HIGH);
  analogWrite(motEn3, 255);
}

void motFrontLeftFwd () {
  digitalWrite(mot4a, HIGH);
  digitalWrite(mot4b, LOW);
  analogWrite(motEn4, 255);
}

void frontMotForward(){
  motFrontRightFwd();
  motFrontLeftFwd();
}

void rearMotForward(){
  motRearRightFwd();
  motRearLeftFwd();
}

void allMotForward(){
  frontMotForward();
  rearMotForward();
}

void allMotStop () {
  digitalWrite(mot1a, LOW);
  digitalWrite(mot1b, LOW);
  analogWrite(motEn1, 0);
  digitalWrite(mot2a, LOW);
  digitalWrite(mot2b, LOW);
  analogWrite(motEn2, 0);
  digitalWrite(mot3a, LOW);
  digitalWrite(mot3b, LOW);
  analogWrite(motEn3, 0);
  digitalWrite(mot4a, LOW);
  digitalWrite(mot4b, LOW);
  analogWrite(motEn4, 0);
}

void allMotReverse(){
  digitalWrite(mot1a, LOW);
  digitalWrite(mot1b, HIGH);
  analogWrite(motEn1, 125);
  digitalWrite(mot2a, HIGH);
  digitalWrite(mot2b, LOW);
  analogWrite(motEn2, 125);  
  digitalWrite(mot3a, HIGH);
  digitalWrite(mot3b, LOW);
  analogWrite(motEn3, 125); 
  digitalWrite(mot4a, LOW);
  digitalWrite(mot4b, HIGH);
  analogWrite(motEn4, 125); 
}
```

After that instead of using another whisker sensor to detect when a step was present I utilised a light sensor that sensed when a step was close using a simple Boolean value.

![IMG_0740.jpeg](COMP208%20-%20Development%20Log%205c105b4361de41f8b609b628b257891b/IMG_0740.jpeg)

I then added this in code to cause the state to transition to the CLIMB state when the LDR detects an object(step).

```arduino
int whiskerActuator1 = 52;
//int whiskerActuator2 = 50;
//int whiskerActuator3 = 48;
//int whiskerActuator4 = 46;

//-----------------------------------------------------------------------------------------------------------------------
//initial ldr

int frontLDR = 8;

//-------------------------------------------------------------------------------------------------------------------------

//laser sensing code

	@@ -104,6 +109,11 @@ void setup() {
  pinMode(linearActuator4b, OUTPUT);

  pinMode(whiskerActuator1, INPUT);
  // pinMode(whiskerActuator2, INPUT);
  // pinMode(whiskerActuator3, INPUT);
  // pinMode(whiskerActuator4, INPUT);

  pinMode(frontLDR,INPUT);

  //initialise tof
  // if(!tof.begin()) {
	@@ -113,17 +123,20 @@ void setup() {

void loop() {
  // tof.rangingTest(&measure, false);
  //while (digitalRead(whiskerActuator1) == 0 || digitalRead(whiskerActuator2) == 0 || digitalRead(whiskerActuator3) == 0 || digitalRead(whiskerActuator4) == 0) {
  allActuatorsDown();
  delay(5000);
  Serial.println("all actuators raised");
  //}

  while (digitalRead(frontLDR) != 0) {
    allMotForward();
    Serial.println("drive to stairs");
  }

  Serial.println("Climbing");
  currentState = CLIMB;
```

I also added some pins in that I believe will be used for the rest of the whisker senors and some commented code to activate the actuators to stop lowering.

### 19/01/23

After attaching all the motor mounts and the whisker sensors I also attached for more encoded motors so that there is more power to move.

![IMG_0743.jpeg](COMP208%20-%20Development%20Log%205c105b4361de41f8b609b628b257891b/IMG_0743.jpeg)

After adding the encoded motors I wrote code for the middle motor control and implemented the code for each whisker sensor to be utilised.

```arduino
#include "Adafruit_VL53L0X.h"
#include <Encoder.h>
enum State {STATIONARY, FORWARD, ROTATE_RIGHT, ROTATE_LEFT, RAISE, LOWER, IDLE, CLIMB};

State currentState = STATIONARY;

//code for encoders
Encoder motorFrontL (2,6);
Encoder motorFrontR (3,7);

long int posFrontL = 0;
long int posFrontR = 0;

int gearingFrontL = 45;
int ticksPerRevolutionFrontL = 6000;

int gearingFrontR = 47;
int ticksPerRevolutionFrontR = 6067;

float wheelRadius = 29;
float wheelCircumference = 2 * 3.14 * wheelRadius;

//distance to move the robot
int distanceFrontL = 1000/5;
int distanceFrontR = 1000/5;

//-------------------------------------------------------------------------------------------------------------
int motEn1 = 13; // motor 1 enable pin for setting power
int motEn2 = 12;
int motEn3 = 11;
int motEn4 = 10;

//pins for the middle motors
int middleMotEnA = 9;
int middleMotEnB = 8;

int middleMotIn1 = 37;
int middleMotIn2 = 35;
int middleMotIn3 = 33;
int middleMotIn4 = 31;

int mot1a = 22; // mot1a and mot 1b to set direction for motor 1
int mot1b = 24;
int mot2a = 26;
int mot2b = 28;
int mot3a = 34;
int mot3b = 36;
int mot4a = 38;
int mot4b = 40;

//-------------------------------------------------------------------------------------------------------------

int linearActuator1a= 39; //1a and 1b for 1st linear actuator to set direction
int linearActuator1b= 41;
int linearActuator2a= 43;
int linearActuator2b= 45;
int linearActuator4a= 47;
int linearActuator4b= 49;
int linearActuator3a= 51;
int linearActuator3b= 53;

///linear actuator enable pins (pwm)
int linearAcuatorEn1 = 32;
int linearAcuatorEn2 = 30;
int linearAcuatorEn3 = 4;
int linearAcuatorEn4 = 5;

//-----------------------------------------------------------------------------------------------------------------------
// initialising whisker sensors

int whiskerActuator1 = 46;
int whiskerActuator2 = 48;
int whiskerActuator3 = 50;
int whiskerActuator4 = 52;

//-----------------------------------------------------------------------------------------------------------------------
//initial ldr

int frontLDR = 44;

//-------------------------------------------------------------------------------------------------------------------------

//laser sensing code

// Objects for the VL53L0X sensors
Adafruit_VL53L0X tof = Adafruit_VL53L0X();

// Measurement data 
VL53L0X_RangingMeasurementData_t measure;

void setup() { 
  pinMode(motEn1, OUTPUT);
  pinMode(motEn2, OUTPUT);
  pinMode(motEn3, OUTPUT);
  pinMode(motEn4, OUTPUT);

  pinMode(middleMotEnA, OUTPUT);
  pinMode(middleMotEnB, OUTPUT);

  pinMode(middleMotIn1, OUTPUT);
  pinMode(middleMotIn2, OUTPUT);
  pinMode(middleMotIn3, OUTPUT);
  pinMode(middleMotIn4, OUTPUT);

  pinMode(mot1a, OUTPUT);
  pinMode(mot1b, OUTPUT);
  pinMode(mot2a, OUTPUT);
  pinMode(mot2b, OUTPUT);
  pinMode(mot3a, OUTPUT);
  pinMode(mot3b, OUTPUT);
  pinMode(mot4a, OUTPUT);
  pinMode(mot4b, OUTPUT);
   
  Serial.begin(115200);
  Serial.println("yo");

  pinMode(linearActuator1a, OUTPUT);
  pinMode(linearActuator1b, OUTPUT);
  pinMode(linearActuator2a, OUTPUT);
  pinMode(linearActuator2b, OUTPUT);
  pinMode(linearActuator3a, OUTPUT);
  pinMode(linearActuator3b, OUTPUT);
  pinMode(linearActuator4a, OUTPUT);
  pinMode(linearActuator4b, OUTPUT);

  pinMode(whiskerActuator1, INPUT);
  pinMode(whiskerActuator2, INPUT);
  pinMode(whiskerActuator3, INPUT);
  pinMode(whiskerActuator4, INPUT);

  pinMode(frontLDR,INPUT);

  //initialise tof
  if(!tof.begin()) {
    Serial.println("Failed to initiate tof");
  }
}

void loop() {
  tof.rangingTest(&measure, false);

  //while atleast one actuator is not completely lowered lower the actuators
  while (digitalRead(whiskerActuator1) == 0 || digitalRead(whiskerActuator2) == 0 || digitalRead(whiskerActuator3) == 0 || digitalRead(whiskerActuator4) == 0){
    allActuatorsDown();
    Serial.println("all actuators lowered");
  }
  allActuatorsStop();

  while (digitalRead(frontLDR) != 0) {
    allMotForward();
    Serial.println("drive to stairs");
  }
  
  Serial.println("Climbing");
  currentState = CLIMB;
  
  
  

  //----------------------------------------
  //code to do odometry
  // posFrontL = motorFrontL.read();
  // while (motorFrontL.read() < ticksPerRevolutionFrontL) {
  //   Serial.println(motorFrontL.read());
  //   motFrontLeftFwd();
  // }
  // allMotStop();
  // Serial.println(motorFrontL.read());

  //-----------------------------------------
  //code to switch states based on sensors
  // if (measure.RangeMilliMeter > 100) {
  //   currentState = FORWARD;
  // } else if (measure.RangeMilliMeter > 100 & /* digitalRead(frontWhisker) == HIGH */ true) {
  //     currentState = CLIMB;
  // } else if (/* reached the top of flight 1 */true) {
  //   for (/* certain amount of encoder ticks */ true) {
  //     currentState = ROTATE_RIGHT;
  //   }
  //   for (/* certain amount of encoder ticks */ true) {
  //     currentState = FORWARD;
  //   }
  //   for (/* certain amount of encoder ticks */ true) {
  //     currentState = ROTATE_RIGHT;
  //   }
  // } else if (/* reached top of flight 2 */ true) {
  //   currentState = STATIONARY;
  // } 

  

  switch (currentState) {
    case STATIONARY:
     allMotStop();
     allActuatorsStop();
     break;
    
    case FORWARD:
      allMotForward();
      break;
    
    case ROTATE_RIGHT:
      motFrontLeftFwd();
      motMiddleLeftFwd();
      motRearLeftFwd();
      break;

    case ROTATE_LEFT:
      motFrontRightFwd();
      motMiddleRightFwd();
      motRearRightFwd();
      break;
    
    case RAISE:
      allActuatorsDown();
      break;

    case LOWER:
      allActuatorsUp();
      break;
    
    case IDLE:
      allActuatorsStop();
      break;

    case CLIMB:
    //raising first actuator above stairs and lowering till it hits it
      actuatorOneUp();
      delay(10000);
      allMotForward();
      delay(10000);
      allMotStop();
      
      //check to see if the whisker sensor is pressed down
      Serial.println(digitalRead(whiskerActuator1));
      while (digitalRead(whiskerActuator1) == 0) {
        actuatorOneDown();
      } 
      actuatorOneStop();
      Serial.println("actuator one on stair");
      //moving the middle actuators above stairs and lowering them until each whisker detects ground
      middleActuatorsUp();
      delay(10000);
      allMotForward();
      delay(10000);
      allMotStop();
      while(digitalRead(whiskerActuator2) == LOW) {
        actuatorTwoDown();
      }
      actuatorTwoStop();

      while(digitalRead(whiskerActuator3) == LOW) {
        actuatorThreeDown();
      }
      actuatorThreeStop();
        // //lift final leg above
        // actuatorFourUp();
        // delay(10000);
        // allMotForward();
        // delay(10000);
        // allMotStop();
        // //digitalRead(whiskerActuator4) == LOW
        // //if (false) {
        // actuatorFourDown();
        // delay(5000);
        // //} else {
        // actuatorFourStop();
        // //}
      
      
  }

}

void actuatorOneUp()
{   
  digitalWrite(linearActuator1a,LOW);
  digitalWrite(linearActuator1b,HIGH);
  analogWrite(linearAcuatorEn1, 150);
} 
  
void actuatorOneDown() {   
  digitalWrite(linearActuator1a,HIGH);
  digitalWrite(linearActuator1b,LOW);
  analogWrite(linearAcuatorEn1, 150); 
}

void actuatorOneStop () {
  digitalWrite(linearActuator1a,LOW);
  digitalWrite(linearActuator1b,LOW);  
}

void actuatorTwoUp() {
  digitalWrite(linearActuator2a,HIGH);
  digitalWrite(linearActuator2b,LOW);
  analogWrite(linearAcuatorEn2, 150);
}
     
void actuatorTwoDown() {
  digitalWrite(linearActuator2a,LOW);
  digitalWrite(linearActuator2b,HIGH);
  analogWrite(linearAcuatorEn2, 150);
}

void actuatorTwoStop () {
  digitalWrite(linearActuator2a,LOW);
  digitalWrite(linearActuator2b,LOW);  
}

void actuatorThreeUp() {
  digitalWrite(linearActuator3a,HIGH);
  digitalWrite(linearActuator3b,LOW);
  analogWrite(linearAcuatorEn3, 150);
}
     
void actuatorThreeDown() {
  digitalWrite(linearActuator3a,LOW);
  digitalWrite(linearActuator3b,HIGH);
  analogWrite(linearAcuatorEn3, 150);
}

void actuatorThreeStop () {
  digitalWrite(linearActuator3a,LOW);
  digitalWrite(linearActuator3b,LOW);  
}

void actuatorFourUp() {
  digitalWrite(linearActuator4a,HIGH);
  digitalWrite(linearActuator4b,LOW);
  analogWrite(linearAcuatorEn4, 255);
}
     
void actuatorFourDown() {
  digitalWrite(linearActuator4a,LOW);
  digitalWrite(linearActuator4b,HIGH);
  analogWrite(linearAcuatorEn4, 250);
}

void actuatorFourStop () {
  digitalWrite(linearActuator4a,LOW);
  digitalWrite(linearActuator4b,LOW);  
}

void allActuatorsDown(){
  actuatorOneDown();
  actuatorTwoDown();
  actuatorThreeDown();
  actuatorFourDown();
}

void allActuatorsUp(){
  actuatorOneUp();
  actuatorTwoUp();
  actuatorThreeUp();
  actuatorFourUp();
}

void allActuatorsStop(){
  actuatorOneStop();
  actuatorTwoStop();
  actuatorThreeStop();
  actuatorFourStop();
}

void middleActuatorsUp(){
  actuatorTwoUp();
  actuatorThreeUp();
}

void middleActuatorsDown(){
  actuatorTwoDown();
  actuatorThreeDown();
}

//functions for control of the motors
void motFrontRightFwd () {
  digitalWrite(mot1a, HIGH);
  digitalWrite(mot1b, LOW);
  analogWrite(motEn1, 255);
}

void motMiddleRightFwd () {
  digitalWrite(middleMotIn1, HIGH);
  digitalWrite(middleMotIn2, LOW);
  analogWrite(middleMotEnA, 255);
}

void motRearRightFwd () {
  digitalWrite(mot2a, LOW);
  digitalWrite(mot2b, HIGH);
  analogWrite(motEn2, 255);
}

void motFrontLeftFwd () {
  digitalWrite(mot4a, HIGH);
  digitalWrite(mot4b, LOW);
  analogWrite(motEn4, 255);
}

void motMiddleLeftFwd () {
  digitalWrite(middleMotIn3, HIGH);
  digitalWrite(middleMotIn4, LOW);
  analogWrite(middleMotEnB, 255);
}

void motRearLeftFwd () {
  digitalWrite(mot3a, LOW);
  digitalWrite(mot3b, HIGH);
  analogWrite(motEn3, 255);
}

void frontMotForward(){
  motFrontRightFwd();
  motFrontLeftFwd();
}

void middleMotForward(){
  motMiddleRightFwd();
  motMiddleLeftFwd();
}

void rearMotForward(){
  motRearRightFwd();
  motRearLeftFwd();
}

void allMotForward(){
  frontMotForward();
  middleMotForward();
  rearMotForward();
}

void allMotStop () {
  digitalWrite(mot1a, LOW);
  digitalWrite(mot1b, LOW);
  analogWrite(motEn1, 0);
  digitalWrite(mot2a, LOW);
  digitalWrite(mot2b, LOW);
  analogWrite(motEn2, 0);
  digitalWrite(mot3a, LOW);
  digitalWrite(mot3b, LOW);
  analogWrite(motEn3, 0);
  digitalWrite(mot4a, LOW);
  digitalWrite(mot4b, LOW);
  analogWrite(motEn4, 0);

  digitalWrite(middleMotIn1, LOW);
  digitalWrite(middleMotIn2, LOW);
  analogWrite(middleMotEnA, 0);
  digitalWrite(middleMotIn3, LOW);
  digitalWrite(middleMotIn4, LOW);
  analogWrite(middleMotEnB, 0);
}

void allMotReverse(){
  digitalWrite(mot1a, LOW);
  digitalWrite(mot1b, HIGH);
  analogWrite(motEn1, 125);
  digitalWrite(mot2a, HIGH);
  digitalWrite(mot2b, LOW);
  analogWrite(motEn2, 125);  
  digitalWrite(mot3a, HIGH);
  digitalWrite(mot3b, LOW);
  analogWrite(motEn3, 125); 
  digitalWrite(mot4a, LOW);
  digitalWrite(mot4b, HIGH);
  analogWrite(motEn4, 125); 
}
```

This code didn’t work as the whisker sensors were facing the wrong way and got snagged so one of them broke so we then had to turn the robot around so I changed the code to operate in the opposite direction and attached a new sensor.

```arduino
#include "Adafruit_VL53L0X.h"
#include <Encoder.h>
enum State {STATIONARY, FORWARD, ROTATE_RIGHT, ROTATE_LEFT, RAISE, LOWER, IDLE, CLIMB};

State currentState = STATIONARY;

//code for encoders
Encoder motorFrontL (2,30);
Encoder motorFrontR (3,32);

long int posFrontL = 0;
long int posFrontR = 0;

int gearingFrontL = 45;
int ticksPerRevolutionFrontL = 6000;

int gearingFrontR = 47;
int ticksPerRevolutionFrontR = 6067;

float wheelRadius = 29;
float wheelCircumference = 2 * 3.14 * wheelRadius;

//distance to move the robot
int distanceFrontL = 1000/5;
int distanceFrontR = 1000/5;

//-------------------------------------------------------------------------------------------------------------
int motEn1 = 13; // motor 1 enable pin for setting power
int motEn2 = 12;
int motEn3 = 11;
int motEn4 = 10;

//pins for the middle motors
int middleMotEnA = 9;
int middleMotEnB = 8;

int middleMotIn1 = 31;
int middleMotIn2 = 33;
int middleMotIn3 = 35;
int middleMotIn4 = 37;

int mot1a = 22; // mot1a and mot 1b to set direction for motor 1
int mot1b = 24;
int mot2a = 26;
int mot2b = 28;
int mot3a = 34;
int mot3b = 36;
int mot4a = 38;
int mot4b = 40;

//-------------------------------------------------------------------------------------------------------------

int linearActuator1a= 39; //1a and 1b for 1st linear actuator to set direction
int linearActuator1b= 41;
int linearActuator2a= 43;
int linearActuator2b= 45;
int linearActuator4a= 47;
int linearActuator4b= 49;
int linearActuator3a= 51;
int linearActuator3b= 53;

///linear actuator enable pins (pwm)
int linearAcuatorEn1 = 7;
int linearAcuatorEn2 = 6;
int linearAcuatorEn3 = 4;
int linearAcuatorEn4 = 5;

//-----------------------------------------------------------------------------------------------------------------------
// initialising whisker sensors

int whiskerActuator1 = 52;
int whiskerActuator2 = 50;
int whiskerActuator3 = 48;
int whiskerActuator4 = 46;

//-----------------------------------------------------------------------------------------------------------------------
//initial ldr

int frontLDR = 44;

//-------------------------------------------------------------------------------------------------------------------------

//laser sensing code

// Objects for the VL53L0X sensors
Adafruit_VL53L0X tof = Adafruit_VL53L0X();

// Measurement data 
VL53L0X_RangingMeasurementData_t measure;

void setup() { 
  pinMode(motEn1, OUTPUT);
  pinMode(motEn2, OUTPUT);
  pinMode(motEn3, OUTPUT);
  pinMode(motEn4, OUTPUT);

  pinMode(middleMotEnA, OUTPUT);
  pinMode(middleMotEnB, OUTPUT);

  pinMode(middleMotIn1, OUTPUT);
  pinMode(middleMotIn2, OUTPUT);
  pinMode(middleMotIn3, OUTPUT);
  pinMode(middleMotIn4, OUTPUT);

  pinMode(mot1a, OUTPUT);
  pinMode(mot1b, OUTPUT);
  pinMode(mot2a, OUTPUT);
  pinMode(mot2b, OUTPUT);
  pinMode(mot3a, OUTPUT);
  pinMode(mot3b, OUTPUT);
  pinMode(mot4a, OUTPUT);
  pinMode(mot4b, OUTPUT);
   
  Serial.begin(115200);
  Serial.println("yo");

  pinMode(linearActuator1a, OUTPUT);
  pinMode(linearActuator1b, OUTPUT);
  pinMode(linearActuator2a, OUTPUT);
  pinMode(linearActuator2b, OUTPUT);
  pinMode(linearActuator3a, OUTPUT);
  pinMode(linearActuator3b, OUTPUT);
  pinMode(linearActuator4a, OUTPUT);
  pinMode(linearActuator4b, OUTPUT);

  pinMode(whiskerActuator1, INPUT);
  pinMode(whiskerActuator2, INPUT);
  pinMode(whiskerActuator3, INPUT);
  pinMode(whiskerActuator4, INPUT);

  pinMode(frontLDR,INPUT);

  //initialise tof
  if(!tof.begin()) {
    Serial.println("Failed to initiate tof");
  }
}

void loop() {
  tof.rangingTest(&measure, false);

  //while atleast one actuator is not completely lowered lower the actuators
  while (digitalRead(whiskerActuator1) == 0 || digitalRead(whiskerActuator2) == 0 || digitalRead(whiskerActuator3) == 0 || digitalRead(whiskerActuator4) == 0){
    allActuatorsDown();
    Serial.print(digitalRead(whiskerActuator1));
    Serial.print(digitalRead(whiskerActuator2));
    Serial.print(digitalRead(whiskerActuator3));
    Serial.print(digitalRead(whiskerActuator4));
    Serial.println("actuators are lowering");
  }
  allActuatorsStop();
  Serial.println("all actuators lowered");

  while (digitalRead(frontLDR) != 0) {
    allMotForward();
    Serial.println("drive to stairs");
  }
  allMotStop();
  
  Serial.println("Climbing");
  currentState = CLIMB;
  
  
  

  //----------------------------------------
  //code to do odometry
  // posFrontL = motorFrontL.read();
  // while (motorFrontL.read() < ticksPerRevolutionFrontL) {
  //   Serial.println(motorFrontL.read());
  //   motFrontLeftFwd();
  // }
  // allMotStop();
  // Serial.println(motorFrontL.read());

  //-----------------------------------------
  //code to switch states based on sensors
  // if (measure.RangeMilliMeter > 100) {
  //   currentState = FORWARD;
  // } else if (measure.RangeMilliMeter > 100 & /* digitalRead(frontWhisker) == HIGH */ true) {
  //     currentState = CLIMB;
  // } else if (/* reached the top of flight 1 */true) {
  //   for (/* certain amount of encoder ticks */ true) {
  //     currentState = ROTATE_RIGHT;
  //   }
  //   for (/* certain amount of encoder ticks */ true) {
  //     currentState = FORWARD;
  //   }
  //   for (/* certain amount of encoder ticks */ true) {
  //     currentState = ROTATE_RIGHT;
  //   }
  // } else if (/* reached top of flight 2 */ true) {
  //   currentState = STATIONARY;
  // } 

  

  switch (currentState) {
    case STATIONARY:
     allMotStop();
     allActuatorsStop();
     break;
    
    case FORWARD:
      allMotForward();
      break;
    
    case ROTATE_RIGHT:
      motFrontLeftFwd();
      motMiddleLeftFwd();
      motRearLeftFwd();
      break;

    case ROTATE_LEFT:
      motFrontRightFwd();
      motMiddleRightFwd();
      motRearRightFwd();
      break;
    
    case RAISE:
      allActuatorsDown();
      break;

    case LOWER:
      allActuatorsUp();
      break;
    
    case IDLE:
      allActuatorsStop();
      break;

    case CLIMB:
    //raising first actuator above stairs and lowering till it hits it
      actuatorOneUp();
      delay(10000);
      allMotForward();
      delay(3000);
      allMotStop();
      
      //check to see if the whisker sensor is pressed down
      Serial.println(digitalRead(whiskerActuator1));
      while (digitalRead(whiskerActuator1) == 0) {
        actuatorOneDown();
      } 
      actuatorOneStop();
      Serial.println("actuator one on stair");
      //moving the middle actuators above stairs and lowering them until each whisker detects ground
      middleActuatorsUp();
      delay(10000);
      allMotForward();
      delay(6000);
      allMotStop();
      while(digitalRead(whiskerActuator2) == LOW || digitalRead(whiskerActuator3) == LOW) {
        actuatorTwoDown();
        actuatorThreeDown();
      }
      actuatorTwoStop();
      actuatorThreeStop();
      Serial.println("actuator two on stair");
      Serial.println("actuator three on stair");

      //lift final leg above
      actuatorFourUp();
      delay(10000);
      allMotForward();
      delay(3000);
      allMotStop();
      while(digitalRead(whiskerActuator4) == LOW) {
        actuatorFourDown();
      }
      actuatorFourStop();
      Serial.println("actuator four on stair");
  }

}

void actuatorOneUp()
{   
  digitalWrite(linearActuator4a,HIGH);
  digitalWrite(linearActuator4b,LOW);
  analogWrite(linearAcuatorEn4, 150);
} 
  
void actuatorOneDown() {   
  digitalWrite(linearActuator4a,LOW);
  digitalWrite(linearActuator4b,HIGH);
  analogWrite(linearAcuatorEn4, 150); 
}

void actuatorOneStop () {
  digitalWrite(linearActuator4a,LOW);
  digitalWrite(linearActuator4b,LOW);  
}

void actuatorTwoUp() {
  digitalWrite(linearActuator3a,HIGH);
  digitalWrite(linearActuator3b,LOW);
  analogWrite(linearAcuatorEn3, 150);
}
     
void actuatorTwoDown() {
  digitalWrite(linearActuator3a,LOW);
  digitalWrite(linearActuator3b,HIGH);
  analogWrite(linearAcuatorEn3, 150);
}

void actuatorTwoStop () {
  digitalWrite(linearActuator3a,LOW);
  digitalWrite(linearActuator3b,LOW);  
}

void actuatorThreeUp() {
  digitalWrite(linearActuator2a,HIGH);
  digitalWrite(linearActuator2b,LOW);
  analogWrite(linearAcuatorEn2, 150);
}
     
void actuatorThreeDown() {
  digitalWrite(linearActuator2a,LOW);
  digitalWrite(linearActuator2b,HIGH);
  analogWrite(linearAcuatorEn2, 150);
}

void actuatorThreeStop () {
  digitalWrite(linearActuator2a,LOW);
  digitalWrite(linearActuator2b,LOW);  
}

void actuatorFourUp() {
  digitalWrite(linearActuator1a,LOW);
  digitalWrite(linearActuator1b,HIGH);
  analogWrite(linearAcuatorEn1, 255);
}
     
void actuatorFourDown() {
  digitalWrite(linearActuator1a,HIGH);
  digitalWrite(linearActuator1b,LOW);
  analogWrite(linearAcuatorEn1, 250);
}

void actuatorFourStop () {
  digitalWrite(linearActuator1a,LOW);
  digitalWrite(linearActuator1b,LOW);  
}

void allActuatorsDown(){
  actuatorOneDown();
  actuatorTwoDown();
  actuatorThreeDown();
  actuatorFourDown();
}

void allActuatorsUp(){
  actuatorOneUp();
  actuatorTwoUp();
  actuatorThreeUp();
  actuatorFourUp();
}

void allActuatorsStop(){
  actuatorOneStop();
  actuatorTwoStop();
  actuatorThreeStop();
  actuatorFourStop();
}

void middleActuatorsUp(){
  actuatorTwoUp();
  actuatorThreeUp();
}

void middleActuatorsDown(){
  actuatorTwoDown();
  actuatorThreeDown();
}

//functions for control of the motors
void motFrontRightFwd () {
  digitalWrite(mot1a, LOW);
  digitalWrite(mot1b, HIGH);
  analogWrite(motEn1, 100);
}

void motMiddleRightFwd () {
  digitalWrite(middleMotIn1, HIGH);
  digitalWrite(middleMotIn2, LOW);
  analogWrite(middleMotEnA, 100);
}

void motRearRightFwd () {
  digitalWrite(mot2a, HIGH);
  digitalWrite(mot2b, LOW);
  analogWrite(motEn2, 100);
}

void motFrontLeftFwd () {
  digitalWrite(mot4a, LOW);
  digitalWrite(mot4b, HIGH);
  analogWrite(motEn4, 100);
}

void motMiddleLeftFwd () {
  digitalWrite(middleMotIn3, HIGH);
  digitalWrite(middleMotIn4, LOW);
  analogWrite(middleMotEnB, 100);
}

void motRearLeftFwd () {
  digitalWrite(mot3a, HIGH);
  digitalWrite(mot3b, LOW);
  analogWrite(motEn3, 100);
}

void frontMotForward(){
  motFrontRightFwd();
  motFrontLeftFwd();
}

void middleMotForward(){
  motMiddleRightFwd();
  motMiddleLeftFwd();
}

void rearMotForward(){
  motRearRightFwd();
  motRearLeftFwd();
}

void allMotForward(){
  frontMotForward();
  middleMotForward();
  rearMotForward();
}

void allMotStop () {
  digitalWrite(mot1a, LOW);
  digitalWrite(mot1b, LOW);
  analogWrite(motEn1, 0);
  digitalWrite(mot2a, LOW);
  digitalWrite(mot2b, LOW);
  analogWrite(motEn2, 0);
  digitalWrite(mot3a, LOW);
  digitalWrite(mot3b, LOW);
  analogWrite(motEn3, 0);
  digitalWrite(mot4a, LOW);
  digitalWrite(mot4b, LOW);
  analogWrite(motEn4, 0);

  digitalWrite(middleMotIn1, LOW);
  digitalWrite(middleMotIn2, LOW);
  analogWrite(middleMotEnA, 0);
  digitalWrite(middleMotIn3, LOW);
  digitalWrite(middleMotIn4, LOW);
  analogWrite(middleMotEnB, 0);
}
```

This code managed to successfully make the robot mount a platform.

[https://youtu.be/kLWbIXtCWrg?si=8xnjIoMDzubNgqFy](https://youtu.be/kLWbIXtCWrg?si=8xnjIoMDzubNgqFy)

### 20/01/24 Adding PWM to linear actuators

After managing to mount the platform I tried it out on the stairs however due to the linear actuators raising at different rates it meant that it was incredibly unstable. To fix this issue I tuned the enabler values so that all the linear actuators would raise at similar speeds.

```arduino
#include "Adafruit_VL53L0X.h"
#include <Encoder.h>
enum State {STATIONARY, FORWARD, ROTATE_RIGHT, ROTATE_LEFT, RAISE, LOWER, CLIMB};

State currentState = STATIONARY;

//code for encoders
Encoder motorFrontL (2,30);
Encoder motorFrontR (3,32);

long int posFrontL = 0;
long int posFrontR = 0;

int gearingFrontL = 45;
int ticksPerRevolutionFrontL = 6000;

int gearingFrontR = 47;
int ticksPerRevolutionFrontR = 6067;

float wheelRadius = 29;
float wheelCircumference = 2 * 3.14 * wheelRadius;

//distance to move the robot
int distanceFrontL = 1000/5;
int distanceFrontR = 1000/5;

//-------------------------------------------------------------------------------------------------------------
int motEn1 = 13; // motor 1 enable pin for setting power
int motEn2 = 12;
int motEn3 = 11;
int motEn4 = 10;

//pins for the middle motors
int middleMotEnA = 9;
int middleMotEnB = 8;

int middleMotIn1 = 31;
int middleMotIn2 = 33;
int middleMotIn3 = 35;
int middleMotIn4 = 37;

int mot1a = 22; // mot1a and mot 1b to set direction for motor 1
int mot1b = 24;
int mot2a = 26;
int mot2b = 28;
int mot3a = 34;
int mot3b = 36;
int mot4a = 38;
int mot4b = 40;

//-------------------------------------------------------------------------------------------------------------

int linearActuator4a= 39; //1a and 1b for 1st linear actuator to set direction
int linearActuator4b= 41;
int linearActuator3a= 43;
int linearActuator3b= 45;
int linearActuator1a= 47;
int linearActuator1b= 49;
int linearActuator2a= 51;
int linearActuator2b= 53;

///linear actuator enable pins (pwm)
int linearAcuatorEn4 = 6;
int linearAcuatorEn3 = 7;
int linearAcuatorEn2 = 4;
int linearAcuatorEn1 = 5;

//-----------------------------------------------------------------------------------------------------------------------
//defining pins for sensors

int whiskerActuator1 = 52;
int whiskerActuator2 = 50;
int whiskerActuator3 = 48;
int whiskerActuator4 = 46;

int frontLDR = 44;

int leftUltraSonicEcho = 29;
int leftUltraSonicTrig = 27;

int rightUltraSonicEcho = 25;
int rightUltraSonicTrig = 23;

//-------------------------------------------------------------------------------------------------------------------------

//laser sensing code

// Objects for the VL53L0X sensors
Adafruit_VL53L0X tof = Adafruit_VL53L0X();

// Measurement data 
VL53L0X_RangingMeasurementData_t measure;

void setup() { 
  Serial.begin(115200);
  

  //initialising outputs to motors
  pinMode(motEn1, OUTPUT);
  pinMode(motEn2, OUTPUT);
  pinMode(motEn3, OUTPUT);
  pinMode(motEn4, OUTPUT);

  pinMode(middleMotEnA, OUTPUT);
  pinMode(middleMotEnB, OUTPUT);

  pinMode(middleMotIn1, OUTPUT);
  pinMode(middleMotIn2, OUTPUT);
  pinMode(middleMotIn3, OUTPUT);
  pinMode(middleMotIn4, OUTPUT);

  pinMode(mot1a, OUTPUT);
  pinMode(mot1b, OUTPUT);
  pinMode(mot2a, OUTPUT);
  pinMode(mot2b, OUTPUT);
  pinMode(mot3a, OUTPUT);
  pinMode(mot3b, OUTPUT);
  pinMode(mot4a, OUTPUT);
  pinMode(mot4b, OUTPUT);

  //initialising outputs to linear actuators
  pinMode(linearActuator1a, OUTPUT);
  pinMode(linearActuator1b, OUTPUT);
  pinMode(linearActuator2a, OUTPUT);
  pinMode(linearActuator2b, OUTPUT);
  pinMode(linearActuator3a, OUTPUT);
  pinMode(linearActuator3b, OUTPUT);
  pinMode(linearActuator4a, OUTPUT);
  pinMode(linearActuator4b, OUTPUT);

  //initialising sensors as input pins
  pinMode(whiskerActuator1, INPUT);
  pinMode(whiskerActuator2, INPUT);
  pinMode(whiskerActuator3, INPUT);
  pinMode(whiskerActuator4, INPUT);

  pinMode(frontLDR,INPUT);

  //initialise tof
  if(!tof.begin()) {
    Serial.println("Failed to initiate tof");
  }
}

void loop() {
  Serial.println("yo");
  tof.rangingTest(&measure, false);
  //check to see if atleast one actuator is not completely lowereds
  while (digitalRead(whiskerActuator1) == 0 || digitalRead(whiskerActuator2) == 0 || digitalRead(whiskerActuator3) == 0 || digitalRead(whiskerActuator4) == 0){
    allActuatorsDown();
    Serial.print(digitalRead(whiskerActuator1));
    Serial.print(digitalRead(whiskerActuator2));
    Serial.print(digitalRead(whiskerActuator3));
    Serial.print(digitalRead(whiskerActuator4));
    Serial.println("actuators are lowering");
  }
  allActuatorsStop();
  Serial.println("all actuators lowered");

  //check that a step is in front of the front motor mount
  while (digitalRead(frontLDR) != 0) {
    allMotForward();
    Serial.println("drive to stairs");
  }
  allMotStop();

  //change state to the climb state
  Serial.println("Climbing");
  currentState = CLIMB;
  
  
  

  //----------------------------------------
  //code to do odometry
  // posFrontL = motorFrontL.read();
  // while (motorFrontL.read() < ticksPerRevolutionFrontL) {
  //   Serial.println(motorFrontL.read());
  //   motFrontLeftFwd();
  // }
  // allMotStop();
  // Serial.println(motorFrontL.read());

  //-----------------------------------------
  //code to switch states based on sensors
  // if (measure.RangeMilliMeter > 100) {
  //   currentState = FORWARD;
  // } else if (measure.RangeMilliMeter > 100 & /* digitalRead(frontWhisker) == HIGH */ true) {
  //     currentState = CLIMB;
  // } else if (/* reached the top of flight 1 */true) {
  //   for (/* certain amount of encoder ticks */ true) {
  //     currentState = ROTATE_RIGHT;
  //   }
  //   for (/* certain amount of encoder ticks */ true) {
  //     currentState = FORWARD;
  //   }
  //   for (/* certain amount of encoder ticks */ true) {
  //     currentState = ROTATE_RIGHT;
  //   }
  // } else if (/* reached top of flight 2 */ true) {
  //   currentState = STATIONARY;
  // } 

  

  switch (currentState) {
    case STATIONARY:
     allMotStop();
     allActuatorsStop();
     break;
    
    case FORWARD:
      allMotForward();
      break;
    
    case ROTATE_RIGHT:
      motFrontLeftFwd();
      motMiddleLeftFwd();
      motRearLeftFwd();
      break;

    case ROTATE_LEFT:
      motFrontRightFwd();
      motMiddleRightFwd();
      motRearRightFwd();
      break;
    
    case RAISE:
      allActuatorsDown();
      break;

    case LOWER:
      allActuatorsUp();
      break;

    case CLIMB:
      //raising first actuator above stairs and lowering till it hits it
      actuatorOneUp();
      delay(30000);
      allMotForward();
      delay(10000);
      allMotStop();
      
      //check to see if the whisker sensor is pressed down
      while (digitalRead(whiskerActuator1) == 0) {
        actuatorOneDown();
        Serial.println(digitalRead(whiskerActuator1));
      } 
      actuatorOneStop();
      Serial.println("actuator one on stair");
      //moving the middle actuators above stairs and lowering them until each whisker detects ground
      middleActuatorsUp();
      actuatorFourDown(); // for some reason back two actuators only work if both are being sent power by hbridge
      delay(30000);
      allMotForward();
      delay(20000);
      allMotStop();
      while(digitalRead(whiskerActuator2) == LOW || digitalRead(whiskerActuator3) == LOW) {
        actuatorTwoDown();
        actuatorThreeDown();
        actuatorFourDown();
      }
      actuatorTwoStop();
      actuatorThreeStop();
      actuatorFourStop(); 
      Serial.println("actuator two on stair");
      Serial.println("actuator three on stair");

      //raise all legs to lift fourth leg over
      allActuatorsDown();
      delay(30000);
      allMotForward();
      delay(10000);
      allMotStop();
      Serial.println("actuator four on stair");
  }

}

void actuatorOneUp()
{   
  digitalWrite(linearActuator1a,HIGH);
  digitalWrite(linearActuator1b,LOW);
  analogWrite(linearAcuatorEn1, 230);
} 
  
void actuatorOneDown() {   
  digitalWrite(linearActuator1a,LOW);
  digitalWrite(linearActuator1b,HIGH);
  analogWrite(linearAcuatorEn1, 255); 
}

void actuatorOneStop () {
  digitalWrite(linearActuator1a,LOW);
  digitalWrite(linearActuator1b,LOW);  
}

void actuatorTwoUp() {
  digitalWrite(linearActuator2a,HIGH);
  digitalWrite(linearActuator2b,LOW);
  analogWrite(linearAcuatorEn2, 235);
}
     
void actuatorTwoDown() {
  digitalWrite(linearActuator2a,LOW);
  digitalWrite(linearActuator2b,HIGH);
  analogWrite(linearAcuatorEn2, 225);
}

void actuatorTwoStop () {
  digitalWrite(linearActuator2a,LOW);
  digitalWrite(linearActuator2b,LOW);  
}

void actuatorThreeUp() {
  digitalWrite(linearActuator3a,HIGH);
  digitalWrite(linearActuator3b,LOW);
  analogWrite(linearAcuatorEn3, 190);
}
     
void actuatorThreeDown() {
  digitalWrite(linearActuator3a,LOW);
  digitalWrite(linearActuator3b,HIGH);
  analogWrite(linearAcuatorEn3, 195);
}

void actuatorThreeStop () {
  digitalWrite(linearActuator3a,LOW);
  digitalWrite(linearActuator3b,LOW);  
}

void actuatorFourUp() {
  digitalWrite(linearActuator4a,LOW);
  digitalWrite(linearActuator4b,HIGH);
  analogWrite(linearAcuatorEn4, 100);
}
     
void actuatorFourDown() {
  digitalWrite(linearActuator4a,HIGH);
  digitalWrite(linearActuator4b,LOW);
  analogWrite(linearAcuatorEn4, 130);
}

void actuatorFourStop () {
  digitalWrite(linearActuator4a,LOW);
  digitalWrite(linearActuator4b,LOW);  
}

void allActuatorsDown(){
  actuatorOneDown();
  actuatorTwoDown();
  actuatorThreeDown();
  actuatorFourDown();
}

void allActuatorsUp(){
  actuatorOneUp();
  actuatorTwoUp();
  actuatorThreeUp();
  actuatorFourUp();
}

void allActuatorsStop(){
  actuatorOneStop();
  actuatorTwoStop();
  actuatorThreeStop();
  actuatorFourStop();
}

void middleActuatorsUp(){
  actuatorTwoUp();
  actuatorThreeUp();
}

void middleActuatorsDown(){
  actuatorTwoDown();
  actuatorThreeDown();
}

//functions for control of the motors
void motFrontRightFwd () {
  digitalWrite(mot1a, LOW);
  digitalWrite(mot1b, HIGH);
  analogWrite(motEn1, 100);
}

void motMiddleRightFwd () {
  digitalWrite(middleMotIn1, HIGH);
  digitalWrite(middleMotIn2, LOW);
  analogWrite(middleMotEnA, 100);
}

void motRearRightFwd () {
  digitalWrite(mot2a, HIGH);
  digitalWrite(mot2b, LOW);
  analogWrite(motEn2, 100);
}

void motFrontLeftFwd () {
  digitalWrite(mot4a, LOW);
  digitalWrite(mot4b, HIGH);
  analogWrite(motEn4, 100);
}

void motMiddleLeftFwd () {
  digitalWrite(middleMotIn3, HIGH);
  digitalWrite(middleMotIn4, LOW);
  analogWrite(middleMotEnB, 100);
}

void motRearLeftFwd () {
  digitalWrite(mot3a, HIGH);
  digitalWrite(mot3b, LOW);
  analogWrite(motEn3, 100);
}

void frontMotForward(){
  motFrontRightFwd();
  motFrontLeftFwd();
}

void middleMotForward(){
  motMiddleRightFwd();
  motMiddleLeftFwd();
}

void rearMotForward(){
  motRearRightFwd();
  motRearLeftFwd();
}

void allMotForward(){
  frontMotForward();
  middleMotForward();
  rearMotForward();
}

void allMotStop () {
  digitalWrite(mot1a, LOW);
  digitalWrite(mot1b, LOW);
  analogWrite(motEn1, 0);
  digitalWrite(mot2a, LOW);
  digitalWrite(mot2b, LOW);
  analogWrite(motEn2, 0);
  digitalWrite(mot3a, LOW);
  digitalWrite(mot3b, LOW);
  analogWrite(motEn3, 0);
  digitalWrite(mot4a, LOW);
  digitalWrite(mot4b, LOW);
  analogWrite(motEn4, 0);

  digitalWrite(middleMotIn1, LOW);
  digitalWrite(middleMotIn2, LOW);
  analogWrite(middleMotEnA, 0);
  digitalWrite(middleMotIn3, LOW);
  digitalWrite(middleMotIn4, LOW);
  analogWrite(middleMotEnB, 0);
}
```

After adding PWM I tested it on the stairs.

[https://youtu.be/qCwaqDmf4fY?si=i20znzdNyJkW5aEp](https://youtu.be/qCwaqDmf4fY?si=i20znzdNyJkW5aEp)

When attempting to lift the middle linear actuators only one raised. After testing it a bunch I found out that the two rear actuators don’t work unless they are both having data sent to it so while the third one is raised I lower the fourth one which changes nothing about the functionality of the fourth actuator but means that both middle actuators raise.

[https://youtu.be/PiSx3NKoPDM?si=jyjmFVQ1GxR7BNM9](https://youtu.be/PiSx3NKoPDM?si=jyjmFVQ1GxR7BNM9)

Due to the tread on the stairs I had to manually press down the whisker sensor and if it got between the tread the wheels aren’t good enough to pull it over the stair.

### 22/01/24

To help move the stair climber forward I made the wheels a bit smaller to fit rubber bands around so the whisker sensors still touch the floor.

I also changed the code to add the rotate right function which will occur when a wall is detected.

```arduino
void loop() {
  Serial.println("yo");
  tof.rangingTest(&measure, false);
  //check to see if atleast one actuator is not completely lowereds
  while (digitalRead(whiskerActuator1) == 0 || digitalRead(whiskerActuator2) == 0 || digitalRead(whiskerActuator3) == 0 || digitalRead(whiskerActuator4) == 0){
    currentState = RAISE;
    Serial.print(digitalRead(whiskerActuator1));
    Serial.print(digitalRead(whiskerActuator2));
    Serial.print(digitalRead(whiskerActuator3));
    Serial.print(digitalRead(whiskerActuator4));
    Serial.println("actuators are lowering");
  }
  //code if whiskers dont work  
  // currentState = RAISE;
  // delay(10000);
  // allActuatorsStop();
  Serial.println("all actuators lowered");
  Serial.println(measure.RangeMilliMeter);
  //check to see if there is a front wall
  if (measure.RangeMilliMeter > 600) {
    currentState = FORWARD; 
    Serial.println("forward");
  //if front wall present and no stairs present turn right
  } else if(measure.RangeMilliMeter < 600 && digitalRead(frontLDR) !=0) {
    currentState = ROTATE_RIGHT;
    Serial.println("rotate right");
  } else if (digitalRead(frontLDR == 0)) {
    //change state to the climb state
    Serial.println("Climbing");
    allMotStop();
    currentState = CLIMB;
  }
```